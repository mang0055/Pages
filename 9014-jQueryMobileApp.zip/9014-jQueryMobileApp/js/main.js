$(function () {
    $("#mypanel").panel();
});
var stepNum = {
    pageNum: 1,
    dataPassed: "I'm cool"
};
$(document).on("mobileinit", function () {});
$(document).on("ready", function (ev) {

    $('.ui-btn').on("click", function () {
        var usersid = $(this).attr("id");
        if (id = 'btn_change') {
            //alert('me');
            $.mobile.changeGlobalTheme("b");
        }
    });
    $("#startTut").on("click", function (ev) {
        ev.preventDefault();
        if (localStorage.getItem("step")) {
            stepNum = JSON.parse(localStorage.getItem("step"))
        }
        var returnPage = "#win" + stepNum.pageNum.toString();
        $.mobile.pageContainer.pagecontainer("change", returnPage)
    });
    $(".nextP").on("click", function (ev) {
        stepNum.pageNum += 1;
        localStorage.setItem("step", JSON.stringify(stepNum))
    });
    $(".backP").on("click", function (ev) {
        stepNum.pageNum -= 1;
        localStorage.setItem("step", JSON.stringify(stepNum))
    })
});
$.mobile.changeGlobalTheme = function (theme) {
    // These themes will be cleared, add more
    // swatch letters as needed.
    var themes = " a b c d e";

    // Updates the theme for all elements that match the
    // CSS selector with the specified theme class.
    function setTheme(cssSelector, themeClass, theme) {
        $(cssSelector)
            .removeClass(themes.split(" ").join(" " + themeClass + "-"))
            .addClass(themeClass + "-" + theme)
            .attr("data-theme", theme);
    }

    // Add more selectors/theme classes as needed.
    setTheme(".ui-mobile-viewport", "ui-overlay", theme);
    setTheme("[data-role='page']", "ui-body", theme);
    setTheme("[data-role='header']", "ui-bar", theme);
    setTheme("[data-role='listview'] > li", "ui-bar", theme);
    setTheme(".ui-btn", "ui-btn-up", theme);
    setTheme(".ui-btn", "ui-btn-hover", theme);
};